# Notepad-Using-CSharp-YT
Implementation of notepad application in C#

This is a C# project developed in VS2015 and is a replica of notepad application in Windows.
